/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX, Sparkles, SlidersHorizontal, ArrowLeftRight, Code2 } from 'lucide-react';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { DashboardPreview } from './components/DashboardPreview';
import { AmbientBackground } from './components/AmbientBackground';
import { toggleSound, isSoundEnabled, playSound } from './utils/audio';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'login' | 'register' | 'dashboard'>('login');
  const [activeUser, setActiveUser] = useState<string>('alex');
  const [isOriginalMode, setIsOriginalMode] = useState(false);
  const [soundOn, setSoundOn] = useState(true);

  const handleSoundToggle = () => {
    const updated = toggleSound();
    setSoundOn(updated);
    if (updated) {
      playSound('pop');
    }
  };

  const handleSuccessfulAuth = (username: string) => {
    setActiveUser(username || 'alex');
    setCurrentPage('dashboard');
  };

  return (
    <div className="min-h-screen bg-[#050506] text-[#f4f4f5] font-sans antialiased relative selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* Dynamic Ambient Background */}
      <AmbientBackground />

      {/* Top Floating Control Bar */}
      <header className="fixed top-3 left-1/2 -translate-x-1/2 z-40 w-full max-w-xl px-4 pointer-events-none">
        <div className="flex items-center justify-between p-1.5 px-3 rounded-full bg-[#0c0c0e]/80 border border-[#1f1f23] backdrop-blur-xl shadow-xl pointer-events-auto text-xs">
          {/* Logo / Title */}
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-xs tracking-tight text-white flex items-center">
              twoside<span className="text-primary">.</span>
            </span>
            <span className="hidden sm:inline-block text-[10px] text-zinc-500 font-mono">
              v2.0 preview
            </span>
          </div>

          {/* Page Switcher Tabs */}
          {currentPage !== 'dashboard' && (
            <div className="flex items-center bg-[#161619] p-0.5 rounded-full border border-white/5">
              <button
                onClick={() => {
                  playSound('toggle');
                  setCurrentPage('login');
                }}
                className={`relative px-3 py-1 rounded-full text-[11px] font-medium transition-all cursor-pointer ${
                  currentPage === 'login'
                    ? 'text-[#050506] font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {currentPage === 'login' && (
                  <motion.div
                    layoutId="activeAuthTab"
                    className="absolute inset-0 bg-primary rounded-full shadow-sm"
                    transition={{ type: 'spring', damping: 20, stiffness: 300 }}
                  />
                )}
                <span className="relative z-10">Log In</span>
              </button>

              <button
                onClick={() => {
                  playSound('toggle');
                  setCurrentPage('register');
                }}
                className={`relative px-3 py-1 rounded-full text-[11px] font-medium transition-all cursor-pointer ${
                  currentPage === 'register'
                    ? 'text-[#050506] font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {currentPage === 'register' && (
                  <motion.div
                    layoutId="activeAuthTab"
                    className="absolute inset-0 bg-primary rounded-full shadow-sm"
                    transition={{ type: 'spring', damping: 20, stiffness: 300 }}
                  />
                )}
                <span className="relative z-10">Register</span>
              </button>
            </div>
          )}

          {/* Quick Utility Toggles */}
          <div className="flex items-center gap-1.5">
            {/* Compare Original vs Beautified */}
            {currentPage !== 'dashboard' && (
              <button
                onClick={() => {
                  playSound('toggle');
                  setIsOriginalMode(!isOriginalMode);
                }}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-medium border transition-all cursor-pointer ${
                  isOriginalMode
                    ? 'bg-amber-500/15 border-amber-500/30 text-amber-300'
                    : 'bg-primary/10 border-primary/20 text-primary hover:bg-primary/20'
                }`}
                title="Toggle between Original Code vs Beautified Deluxe UI"
              >
                {isOriginalMode ? (
                  <>
                    <Code2 className="w-3 h-3" />
                    <span>Original Code</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3 h-3" />
                    <span>Beautified</span>
                  </>
                )}
              </button>
            )}

            {/* Audio Toggle */}
            <button
              onClick={handleSoundToggle}
              className={`p-1.5 rounded-full border transition-colors cursor-pointer ${
                soundOn
                  ? 'bg-[#161619] border-white/10 text-zinc-300 hover:text-white'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-600'
              }`}
              title={soundOn ? 'Sound Effects Enabled (Click to Mute)' : 'Sound Muted (Click to Unmute)'}
            >
              {soundOn ? <Volume2 className="w-3.5 h-3.5 text-primary" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 pt-10 sm:pt-6">
        <AnimatePresence mode="wait">
          {currentPage === 'login' && (
            <motion.div
              key="login"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              <LoginPage
                onNavigate={(page) => setCurrentPage(page)}
                onSuccessLogin={handleSuccessfulAuth}
                isOriginalView={isOriginalMode}
              />
            </motion.div>
          )}

          {currentPage === 'register' && (
            <motion.div
              key="register"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              <RegisterPage
                onNavigate={(page) => setCurrentPage(page)}
                onSuccessRegister={handleSuccessfulAuth}
                isOriginalView={isOriginalMode}
              />
            </motion.div>
          )}

          {currentPage === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <DashboardPreview
                username={activeUser}
                onLogout={() => {
                  setCurrentPage('login');
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
