import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

export function AmbientBackground() {
  const [mousePos, setMousePos] = useState({ x: -500, y: -500 });

  useEffect(() => {
    const handlePointerMove = (e: PointerEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('pointermove', handlePointerMove);
    return () => window.removeEventListener('pointermove', handlePointerMove);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {/* Dynamic Cursor Spotlight */}
      <div
        className="absolute w-[500px] h-[500px] rounded-full blur-3xl opacity-20 transition-transform duration-300 ease-out"
        style={{
          background: 'radial-gradient(circle, rgba(34, 197, 94, 0.25) 0%, rgba(34, 197, 94, 0) 70%)',
          transform: `translate(${mousePos.x - 250}px, ${mousePos.y - 250}px)`,
        }}
      />

      {/* Top Center Ambient Bloom */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Bottom Subtle Secondary Bloom */}
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-emerald-950/20 rounded-full blur-[90px] pointer-events-none" />

      {/* Grid Pattern */}
      <div className="absolute inset-0 twoside-grid opacity-60" />

      {/* Floating Two-Side Finance Tokens */}
      <div className="absolute inset-0">
        {[
          { text: '💸', top: '15%', left: '12%', duration: 7, delay: 0 },
          { text: '🤝', top: '22%', right: '14%', duration: 8, delay: 1 },
          { text: '+ $', top: '75%', left: '16%', duration: 6, delay: 2 },
          { text: '- ₦', top: '68%', right: '15%', duration: 9, delay: 0.5 },
          { text: '⇌', top: '45%', left: '8%', duration: 7.5, delay: 3 },
          { text: '✦', top: '48%', right: '9%', duration: 8.5, delay: 1.5 },
        ].map((item, idx) => (
          <motion.div
            key={idx}
            className="absolute hidden md:flex items-center justify-center w-8 h-8 rounded-xl bg-[#0c0c0e]/60 border border-[#1f1f23] text-xs font-mono text-zinc-500 backdrop-blur-sm select-none shadow-sm"
            style={{
              top: item.top,
              left: item.left,
              right: item.right,
            }}
            animate={{
              y: [0, -12, 0],
              rotate: [0, 4, -4, 0],
              opacity: [0.35, 0.7, 0.35],
            }}
            transition={{
              duration: item.duration,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: item.delay,
            }}
          >
            {item.text}
          </motion.div>
        ))}
      </div>
    </div>
  );
}
