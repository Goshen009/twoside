import { motion } from 'motion/react';
import { Check, X } from 'lucide-react';

interface PasswordStrengthProps {
  pin: string;
  confirmPin?: string;
  isConfirm?: boolean;
}

export function PasswordStrength({ pin, confirmPin, isConfirm = false }: PasswordStrengthProps) {
  if (!pin) return null;

  // Calculate strength score
  let score = 0;
  if (pin.length >= 6) score += 1;
  if (pin.length >= 8) score += 1;
  if (/[0-9]/.test(pin) && /[a-zA-Z]/.test(pin)) score += 1;
  if (/[^a-zA-Z0-9]/.test(pin) || pin.length >= 10) score += 1;

  const strengthLabels = [
    { label: 'Too short 🐣', color: 'bg-zinc-600', text: 'text-zinc-400' },
    { label: 'Getting there ⚡', color: 'bg-amber-500', text: 'text-amber-400' },
    { label: 'Good & Secure 🛡️', color: 'bg-emerald-500', text: 'text-emerald-400' },
    { label: 'Bank Vault Ready 🏦', color: 'bg-primary', text: 'text-primary' },
  ];

  const currentStrength = strengthLabels[Math.max(0, score - 1)] || strengthLabels[0];
  const isMatching = isConfirm && confirmPin ? pin === confirmPin : null;

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      className="space-y-2 pt-1 pb-1 overflow-hidden"
    >
      {/* Strength Segments */}
      <div className="flex items-center gap-1.5">
        {[1, 2, 3, 4].map((step) => {
          const isActive = score >= step;
          return (
            <div
              key={step}
              className="h-1 flex-1 rounded-full bg-zinc-800 overflow-hidden transition-all duration-300"
            >
              <div
                className={`h-full transition-all duration-300 ${
                  isActive ? currentStrength.color : 'w-0'
                }`}
                style={{ width: isActive ? '100%' : '0%' }}
              />
            </div>
          );
        })}
      </div>

      {/* Label and tips */}
      <div className="flex items-center justify-between text-[10px] text-zinc-400 px-1">
        <span>Security Level:</span>
        <span className={`font-medium ${currentStrength.text}`}>{currentStrength.label}</span>
      </div>

      {/* PIN Match Check for Register */}
      {isConfirm && confirmPin && (
        <div className="flex items-center gap-1.5 text-[10px] px-1">
          {isMatching ? (
            <span className="text-primary flex items-center gap-1 font-medium">
              <Check className="w-3 h-3" /> Passwords match perfectly
            </span>
          ) : (
            <span className="text-red-400 flex items-center gap-1">
              <X className="w-3 h-3" /> Passwords do not match yet
            </span>
          )}
        </div>
      )}
    </motion.div>
  );
}
