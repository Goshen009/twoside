import { useState, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, Eye, EyeOff, Lock, User, Sparkles, ArrowRight, CheckCircle2, UserPlus } from 'lucide-react';
import confetti from 'canvas-confetti';
import { TwosideMascot } from './TwosideMascot';
import { PasswordStrength } from './PasswordStrength';
import { playSound } from '../utils/audio';

interface RegisterPageProps {
  onNavigate: (page: 'login' | 'register' | 'dashboard') => void;
  onSuccessRegister?: (username: string) => void;
  isOriginalView?: boolean;
}

export function RegisterPage({ onNavigate, onSuccessRegister, isOriginalView = false }: RegisterPageProps) {
  const [username, setUsername] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeField, setActiveField] = useState<'username' | 'pin' | 'confirm_pin' | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [agreedTerms, setAgreedTerms] = useState(true);

  const handleDemoFill = () => {
    playSound('pop');
    const randomNum = Math.floor(100 + Math.random() * 900);
    setUsername(`trader_sam_${randomNum}`);
    setPin('SuperVault99$');
    setConfirmPin('SuperVault99$');
    setError(null);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!username.trim()) {
      playSound('error');
      setError('Please choose a username');
      return;
    }

    if (username.length < 3) {
      playSound('error');
      setError('Username must be at least 3 characters');
      return;
    }

    if (!pin.trim()) {
      playSound('error');
      setError('Please create a password / PIN');
      return;
    }

    if (pin.length < 6) {
      playSound('error');
      setError('Password must be at least 6 characters');
      return;
    }

    if (pin !== confirmPin) {
      playSound('error');
      setError('Passwords do not match. Please verify.');
      return;
    }

    if (!agreedTerms) {
      playSound('error');
      setError('Please accept terms to continue');
      return;
    }

    playSound('click');
    setLoading(true);

    // Simulate account setup
    setTimeout(() => {
      setLoading(false);
      setIsSuccess(true);
      playSound('success');

      confetti({
        particleCount: 110,
        spread: 85,
        origin: { y: 0.6 },
        colors: ['#22c55e', '#16a34a', '#4ade80', '#ffffff', '#1f1f23'],
      });

      setTimeout(() => {
        if (onSuccessRegister) {
          onSuccessRegister(username);
        } else {
          onNavigate('dashboard');
        }
      }, 1000);
    }, 1200);
  };

  // If user requested raw original layout
  if (isOriginalView) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 relative">
        <div className="absolute top-1/4 -translate-y-1/2 w-64 h-64 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
        <div className="w-full max-w-sm space-y-6 relative z-10">
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.98 }}
                className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-2xl flex items-center gap-2.5 text-xs shadow-lg"
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="text-center space-y-2">
            <div className="inline-flex items-center tracking-tight text-2xl font-bold font-sans text-zinc-100">
              <span>twoside</span>
              <span className="text-primary">.</span>
            </div>
            <p className="text-xs text-muted">Start tracking your expenses and loans instantly</p>
          </div>

          <form
            onSubmit={handleSubmit}
            className="bg-surface/80 border border-white/5 rounded-3xl p-5 space-y-4 shadow-2xl backdrop-blur-xl"
          >
            <div className="space-y-1.5">
              <label className="text-[11px] font-medium text-zinc-300 ml-1">Username</label>
              <input
                type="text"
                placeholder="Choose a username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-background/50 border border-white/5 rounded-2xl px-4 py-3 text-xs text-zinc-100 placeholder:text-muted/50 focus:outline-none focus:border-primary/50 transition-colors"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-medium text-zinc-300 ml-1">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  className="w-full bg-background/50 border border-white/5 rounded-2xl px-4 py-3 text-xs text-zinc-100 placeholder:text-muted/50 focus:outline-none focus:border-primary/50 transition-colors pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-zinc-100 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-medium text-zinc-300 ml-1">Confirm Password</label>
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••"
                value={confirmPin}
                onChange={(e) => setConfirmPin(e.target.value)}
                className="w-full bg-background/50 border border-white/5 rounded-2xl px-4 py-3 text-xs text-zinc-100 placeholder:text-muted/50 focus:outline-none focus:border-primary/50 transition-colors"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 bg-primary hover:bg-primary-hover text-background font-bold text-xs py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-primary/10 cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
              ) : (
                <span>Create Account</span>
              )}
            </button>
          </form>

          <div className="text-center text-xs text-muted">
            Already have an account?{' '}
            <button
              onClick={() => onNavigate('login')}
              className="text-primary hover:underline font-medium cursor-pointer"
            >
              Log In
            </button>
          </div>
        </div>
      </div>
    );
  }

  // BEAUTIFIED DELUXE VERSION
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-6 relative z-10 select-none">
      {/* Dynamic Background Glow */}
      <div className="absolute top-1/4 -translate-y-1/2 w-80 h-80 bg-primary/10 rounded-full blur-3xl pointer-events-none animate-pulse-ring" />

      <div className="w-full max-w-sm space-y-5 relative z-10">
        {/* Interactive Mascot */}
        <TwosideMascot
          isPasswordFocused={activeField === 'pin' || activeField === 'confirm_pin'}
          showPassword={showPassword}
          isSuccess={isSuccess}
          activeField={activeField}
          mode="register"
        />

        {/* Header Branding */}
        <div className="text-center space-y-1.5">
          <div className="inline-flex items-center tracking-tight text-3xl font-extrabold font-sans text-zinc-100 group cursor-default">
            <span>twoside</span>
            <span className="text-primary group-hover:scale-125 transition-transform inline-block">.</span>
          </div>
          <p className="text-xs text-muted flex items-center justify-center gap-1.5 font-medium">
            <span>Zero Spreadsheets</span>
            <span className="w-1 h-1 rounded-full bg-primary/40" />
            <span>Pure Balance</span>
          </p>
        </div>

        {/* Error Notification */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.96 }}
              className="bg-red-500/10 border border-red-500/25 text-red-400 p-3.5 rounded-2xl flex items-center justify-between text-xs shadow-lg backdrop-blur-md"
            >
              <div className="flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{error}</span>
              </div>
              <button
                type="button"
                onClick={() => setError(null)}
                className="text-red-400/60 hover:text-red-400 text-xs font-mono px-1"
              >
                ✕
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Beautified Form */}
        <motion.div
          layout
          className="relative bg-surface/90 border border-white/10 rounded-3xl p-6 shadow-2xl backdrop-blur-2xl transition-all duration-300 hover:border-primary/20"
        >
          {/* Top Rim Light */}
          <div className="absolute top-0 left-6 right-6 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

          {/* Card Header & Fast Autofill */}
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-zinc-300">
              <UserPlus className="w-3.5 h-3.5 text-primary" />
              <span>Create Free Account</span>
            </div>
            <button
              type="button"
              onClick={handleDemoFill}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 text-[10px] font-medium transition-colors cursor-pointer group"
              title="Click to generate random test account"
            >
              <Sparkles className="w-3 h-3 group-hover:rotate-12 transition-transform" />
              <span>Auto-Fill</span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* Username Field */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-medium text-zinc-300 ml-1 flex items-center gap-1.5">
                  <User className="w-3 h-3 text-zinc-500" />
                  <span>Choose Username</span>
                </label>
                {username.length >= 3 && (
                  <span className="text-[10px] text-primary flex items-center gap-1 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                    available
                  </span>
                )}
              </div>
              <div className="relative group">
                <input
                  type="text"
                  placeholder="e.g. jordan_fin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  onFocus={() => {
                    setActiveField('username');
                    playSound('pop');
                  }}
                  onBlur={() => setActiveField(null)}
                  className="w-full bg-background/70 border border-white/5 rounded-2xl px-4 py-3 text-xs text-zinc-100 placeholder:text-muted/50 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/15 transition-all shadow-inner"
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-medium text-zinc-300 ml-1 flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-zinc-500" />
                <span>Password</span>
              </label>
              <div className="relative group">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Create master password"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  onFocus={() => {
                    setActiveField('pin');
                    playSound('pop');
                  }}
                  onBlur={() => setActiveField(null)}
                  className="w-full bg-background/70 border border-white/5 rounded-2xl px-4 py-3 text-xs text-zinc-100 placeholder:text-muted/50 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/15 transition-all shadow-inner pr-10"
                />
                <button
                  type="button"
                  onClick={() => {
                    playSound('peek');
                    setShowPassword(!showPassword);
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-primary transition-colors cursor-pointer p-1"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4 text-primary" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Dynamic Interactive Password Strength */}
              <PasswordStrength pin={pin} />
            </div>

            {/* Confirm Password Field */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-medium text-zinc-300 ml-1 flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-zinc-500" />
                <span>Confirm Password</span>
              </label>
              <div className="relative group">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Repeat master password"
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value)}
                  onFocus={() => {
                    setActiveField('confirm_pin');
                    playSound('pop');
                  }}
                  onBlur={() => setActiveField(null)}
                  className="w-full bg-background/70 border border-white/5 rounded-2xl px-4 py-3 text-xs text-zinc-100 placeholder:text-muted/50 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/15 transition-all shadow-inner"
                />
              </div>

              {/* Confirm status check */}
              {confirmPin && <PasswordStrength pin={pin} confirmPin={confirmPin} isConfirm={true} />}
            </div>

            {/* Terms checkbox */}
            <div className="pt-1">
              <label className="flex items-start gap-2.5 cursor-pointer text-[11px] text-zinc-400 hover:text-zinc-200 select-none">
                <input
                  type="checkbox"
                  checked={agreedTerms}
                  onChange={(e) => {
                    playSound('toggle');
                    setAgreedTerms(e.target.checked);
                  }}
                  className="mt-0.5 w-3.5 h-3.5 rounded bg-background border-zinc-700 text-primary focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#22c55e]"
                />
                <span className="leading-tight">
                  I agree to keep my expenses & loans balanced in peace.
                </span>
              </label>
            </div>

            {/* Submit Button */}
            <motion.button
              type="submit"
              disabled={loading || isSuccess}
              whileTap={{ scale: 0.98 }}
              className={`w-full mt-2 font-bold text-xs py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-lg cursor-pointer disabled:opacity-75 ${
                isSuccess
                  ? 'bg-emerald-400 text-black shadow-emerald-500/30'
                  : 'bg-primary hover:bg-primary-hover text-[#050506] shadow-primary/20 hover:shadow-primary/30'
              }`}
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : isSuccess ? (
                <motion.div
                  initial={{ scale: 0.8 }}
                  animate={{ scale: 1 }}
                  className="flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Account Created!</span>
                </motion.div>
              ) : (
                <>
                  <span>Create Account</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </motion.button>
          </form>
        </motion.div>

        {/* Footer Navigation Link */}
        <div className="p-3 rounded-2xl bg-surface/50 border border-white/5 text-center text-xs text-muted backdrop-blur-md flex items-center justify-center gap-1.5">
          <span>Already have an account?</span>
          <button
            type="button"
            onClick={() => {
              playSound('toggle');
              onNavigate('login');
            }}
            className="text-primary hover:underline font-semibold cursor-pointer transition-colors"
          >
            Log In
          </button>
        </div>
      </div>
    </div>
  );
}
