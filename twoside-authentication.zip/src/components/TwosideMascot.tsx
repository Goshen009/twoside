import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { playSound } from '../utils/audio';

interface MascotProps {
  isPasswordFocused?: boolean;
  showPassword?: boolean;
  isSuccess?: boolean;
  activeField?: 'username' | 'pin' | 'confirm_pin' | null;
  mode?: 'login' | 'register';
}

export function TwosideMascot({
  isPasswordFocused = false,
  showPassword = false,
  isSuccess = false,
  activeField = null,
  mode = 'login',
}: MascotProps) {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isFlipping, setIsFlipping] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const x = (e.clientX / innerWidth - 0.5) * 16;
      const y = (e.clientY / innerHeight - 0.5) * 12;
      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleMascotClick = () => {
    setIsFlipping(true);
    playSound('pop');
    setTimeout(() => setIsFlipping(false), 800);
  };

  // Determine eye offset
  let eyeOffsetX = mousePos.x;
  let eyeOffsetY = mousePos.y;

  if (activeField === 'username') {
    eyeOffsetX = -3;
    eyeOffsetY = 6;
  } else if (activeField === 'pin' || activeField === 'confirm_pin') {
    eyeOffsetX = 0;
    eyeOffsetY = 8;
  }

  const isCoveringEyes = isPasswordFocused && !showPassword;
  const isPeeking = isPasswordFocused && showPassword;

  return (
    <div className="flex flex-col items-center justify-center relative select-none">
      {/* Interactive Mascot Container */}
      <motion.div
        className="relative cursor-pointer group"
        onClick={handleMascotClick}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        animate={{
          rotateY: isFlipping ? 360 : 0,
        }}
        transition={{ duration: 0.7, ease: [0.34, 1.56, 0.64, 1] }}
        title="Click to flip the twoside token!"
      >
        {/* Ambient Ring Glow */}
        <div className="absolute -inset-2 bg-gradient-to-r from-primary/20 via-emerald-400/10 to-primary/20 rounded-full blur-md opacity-60 group-hover:opacity-100 transition-opacity" />

        {/* Mascot Face / Token Shell */}
        <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-b from-[#161619] to-[#0c0c0e] border border-[#1f1f23] p-1.5 shadow-2xl flex flex-col items-center justify-center overflow-hidden">
          {/* Subtle Dual-Arc Accent (Two Sides) */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-80" />
          <div className="absolute -bottom-6 -right-6 w-12 h-12 bg-primary/10 rounded-full blur-sm" />

          {/* Mode Pill Indicator on forehead */}
          <div className="absolute top-2 px-2 py-0.5 rounded-full bg-[#050506]/80 border border-white/5 text-[9px] font-mono text-zinc-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            <span>{mode === 'login' ? 'SIDE A' : 'SIDE B'}</span>
          </div>

          {/* Eyes & Expressions Area */}
          <div className="relative w-14 h-8 mt-2 flex items-center justify-center gap-3">
            {/* Left Eye */}
            <div className="relative w-3.5 h-3.5 rounded-full bg-[#050506] border border-primary/30 flex items-center justify-center overflow-hidden">
              <motion.div
                className="w-2 h-2 rounded-full bg-primary shadow-[0_0_8px_rgba(34,197,94,0.8)]"
                animate={{
                  x: isCoveringEyes ? 0 : eyeOffsetX * 0.25,
                  y: isCoveringEyes ? 0 : eyeOffsetY * 0.25,
                  scaleY: isCoveringEyes ? 0.1 : isSuccess ? 0.2 : 1,
                  scaleX: isCoveringEyes ? 0.1 : 1,
                }}
                transition={{ type: 'spring', damping: 15, stiffness: 200 }}
              />
            </div>

            {/* Right Eye */}
            <div className="relative w-3.5 h-3.5 rounded-full bg-[#050506] border border-primary/30 flex items-center justify-center overflow-hidden">
              <motion.div
                className="w-2 h-2 rounded-full bg-primary shadow-[0_0_8px_rgba(34,197,94,0.8)]"
                animate={{
                  x: isCoveringEyes ? 0 : (isPeeking ? 1 : eyeOffsetX * 0.25),
                  y: isCoveringEyes ? 0 : (isPeeking ? 1 : eyeOffsetY * 0.25),
                  scaleY: isCoveringEyes ? 0.1 : (isPeeking ? 1.3 : isSuccess ? 0.2 : 1),
                  scaleX: isCoveringEyes ? 0.1 : (isPeeking ? 1.3 : 1),
                }}
                transition={{ type: 'spring', damping: 15, stiffness: 200 }}
              />
            </div>

            {/* Hands covering eyes when typing password without reveal */}
            <motion.div
              className="absolute inset-0 flex items-center justify-between px-0.5 pointer-events-none"
              initial={false}
              animate={{
                y: isCoveringEyes ? 0 : 25,
                opacity: isCoveringEyes ? 1 : 0,
              }}
              transition={{ type: 'spring', damping: 18, stiffness: 250 }}
            >
              {/* Left Hand */}
              <div className="w-5 h-5 rounded-full bg-[#161619] border border-primary/40 shadow-lg flex items-center justify-center">
                <div className="w-2.5 h-1 rounded-full bg-zinc-600" />
              </div>
              {/* Right Hand */}
              <div className="w-5 h-5 rounded-full bg-[#161619] border border-primary/40 shadow-lg flex items-center justify-center">
                <div className="w-2.5 h-1 rounded-full bg-zinc-600" />
              </div>
            </motion.div>

            {/* Peeking visor cutout indicator */}
            {isPeeking && (
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="absolute -top-1 right-1 text-[10px]"
              >
                👀
              </motion.div>
            )}
          </div>

          {/* Mouth / Status Bar */}
          <div className="w-6 h-1 rounded-full bg-zinc-800 overflow-hidden mt-1 relative">
            <motion.div
              className="h-full bg-primary"
              animate={{
                width: isSuccess ? '100%' : isPasswordFocused ? '40%' : '70%',
                x: isPasswordFocused ? [0, 4, 0] : 0,
              }}
              transition={{ repeat: isPasswordFocused ? Infinity : 0, duration: 1.5 }}
            />
          </div>
        </div>

        {/* Floating helper bubble on hover */}
        <motion.div
          className="absolute -bottom-5 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap px-2 py-0.5 rounded-md bg-[#0c0c0e] border border-white/10 text-[9px] text-zinc-400 font-mono shadow-md"
        >
          {isCoveringEyes ? 'No peeking! 🙈' : isPeeking ? 'Peek mode ON 👀' : 'Flip coin 🪙'}
        </motion.div>
      </motion.div>
    </div>
  );
}
