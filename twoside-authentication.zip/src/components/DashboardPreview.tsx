import { useState, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  TrendingDown,
  HandCoins,
  Plus,
  LogOut,
  Sparkles,
  ArrowUpRight,
  ArrowDownLeft,
  CheckCircle2,
  Wallet,
  Receipt,
  Users,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { playSound } from '../utils/audio';

interface DashboardPreviewProps {
  username: string;
  onLogout: () => void;
}

interface Transaction {
  id: string;
  title: string;
  personOrCategory: string;
  amount: number;
  type: 'expense' | 'loan_given' | 'loan_taken';
  date: string;
}

export function DashboardPreview({ username, onLogout }: DashboardPreviewProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'expenses' | 'loans'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newAmount, setNewAmount] = useState('');
  const [newType, setNewType] = useState<'expense' | 'loan_given' | 'loan_taken'>('expense');

  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      title: 'Coffee & Breakfast with Sam',
      personOrCategory: 'Samira',
      amount: 14.5,
      type: 'expense',
      date: 'Today, 9:20 AM',
    },
    {
      id: '2',
      title: 'Lent for Concert Ticket',
      personOrCategory: 'Marcus',
      amount: 65.0,
      type: 'loan_given',
      date: 'Yesterday',
    },
    {
      id: '3',
      title: 'Borrowed for Groceries',
      personOrCategory: 'Elena',
      amount: 28.0,
      type: 'loan_taken',
      date: 'Sep 1',
    },
    {
      id: '4',
      title: 'Cloud Server Subscription',
      personOrCategory: 'Infrastructure',
      amount: 12.0,
      type: 'expense',
      date: 'Aug 29',
    },
  ]);

  const totalExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalOwedToYou = transactions
    .filter((t) => t.type === 'loan_given')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalYouOwe = transactions
    .filter((t) => t.type === 'loan_taken')
    .reduce((sum, t) => sum + t.amount, 0);

  const handleAddTransaction = (e: FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newAmount) return;

    playSound('pop');
    const newTx: Transaction = {
      id: String(Date.now()),
      title: newTitle,
      personOrCategory: newType === 'expense' ? 'Personal' : 'Friend',
      amount: parseFloat(newAmount),
      type: newType,
      date: 'Just now',
    };

    setTransactions([newTx, ...transactions]);
    setNewTitle('');
    setNewAmount('');
    setShowAddModal(false);

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#22c55e', '#16a34a', '#f4f4f5'],
    });
  };

  const filtered = transactions.filter((t) => {
    if (activeTab === 'expenses') return t.type === 'expense';
    if (activeTab === 'loans') return t.type === 'loan_given' || t.type === 'loan_taken';
    return true;
  });

  return (
    <div className="min-h-screen p-4 sm:p-6 max-w-2xl mx-auto space-y-6 relative z-10">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-4 rounded-3xl bg-surface/80 border border-white/5 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-primary/20 to-emerald-950/40 border border-primary/30 flex items-center justify-center font-bold text-primary text-sm">
            {username.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-sm text-zinc-100">twoside</span>
              <span className="text-primary font-bold">.</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20 font-mono">
                Active Session
              </span>
            </div>
            <p className="text-[11px] text-muted">Welcome back, @{username}</p>
          </div>
        </div>

        <button
          onClick={() => {
            playSound('toggle');
            onLogout();
          }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-[#161619] hover:bg-zinc-800 border border-white/5 text-xs text-zinc-300 hover:text-white transition-colors cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5 text-zinc-400" />
          <span className="hidden sm:inline">Sign Out</span>
        </button>
      </div>

      {/* Two Sides Balances (Expenses vs Loans) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Side 1: Expenses */}
        <div className="p-5 rounded-3xl bg-surface/90 border border-white/5 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <TrendingDown className="w-16 h-16 text-primary" />
          </div>
          <div className="flex items-center gap-2 text-xs text-muted mb-2">
            <Receipt className="w-3.5 h-3.5 text-primary" />
            <span>Total Expenses</span>
          </div>
          <div className="text-2xl font-black text-zinc-100 font-mono">
            ${totalExpenses.toFixed(2)}
          </div>
          <p className="text-[10px] text-zinc-500 mt-1">Direct spending recorded</p>
        </div>

        {/* Side 2: Peer Loans */}
        <div className="p-5 rounded-3xl bg-surface/90 border border-white/5 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <HandCoins className="w-16 h-16 text-emerald-400" />
          </div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-xs text-muted">
              <Users className="w-3.5 h-3.5 text-primary" />
              <span>Peer Loans</span>
            </div>
            <span className="text-[10px] text-primary font-mono font-semibold">
              +${(totalOwedToYou - totalYouOwe).toFixed(2)} net
            </span>
          </div>
          <div className="flex items-baseline gap-4 font-mono">
            <div>
              <span className="text-[10px] text-zinc-500 block">Owed to you</span>
              <span className="text-lg font-bold text-emerald-400">${totalOwedToYou.toFixed(2)}</span>
            </div>
            <div className="h-6 w-[1px] bg-zinc-800" />
            <div>
              <span className="text-[10px] text-zinc-500 block">You owe</span>
              <span className="text-lg font-bold text-amber-400">${totalYouOwe.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Bar & Filter Tabs */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-surface/90 border border-white/5">
          {(['all', 'expenses', 'loans'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => {
                playSound('toggle');
                setActiveTab(tab);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium capitalize transition-all cursor-pointer ${
                activeTab === tab
                  ? 'bg-primary text-[#050506] font-bold shadow-md'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <button
          onClick={() => {
            playSound('pop');
            setShowAddModal(true);
          }}
          className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-primary hover:bg-primary-hover text-[#050506] font-bold text-xs shadow-lg shadow-primary/20 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Entry</span>
        </button>
      </div>

      {/* Transaction List */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between text-xs text-muted px-2">
          <span>Recent Activity</span>
          <span>{filtered.length} entries</span>
        </div>

        {filtered.map((tx) => {
          const isExpense = tx.type === 'expense';
          const isLoanGiven = tx.type === 'loan_given';

          return (
            <motion.div
              key={tx.id}
              layout
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3.5 rounded-2xl bg-surface/80 hover:bg-[#161619] border border-white/5 flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center border ${
                    isExpense
                      ? 'bg-zinc-900 border-zinc-700 text-zinc-300'
                      : isLoanGiven
                      ? 'bg-emerald-950/40 border-primary/30 text-primary'
                      : 'bg-amber-950/40 border-amber-500/30 text-amber-400'
                  }`}
                >
                  {isExpense ? (
                    <TrendingDown className="w-4 h-4" />
                  ) : isLoanGiven ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : (
                    <ArrowDownLeft className="w-4 h-4" />
                  )}
                </div>

                <div>
                  <div className="text-xs font-semibold text-zinc-100 group-hover:text-white transition-colors">
                    {tx.title}
                  </div>
                  <div className="text-[10px] text-muted flex items-center gap-1.5">
                    <span>{tx.personOrCategory}</span>
                    <span className="w-1 h-1 rounded-full bg-zinc-700" />
                    <span>{tx.date}</span>
                  </div>
                </div>
              </div>

              <div className="text-right font-mono">
                <div
                  className={`text-xs font-bold ${
                    isExpense
                      ? 'text-zinc-200'
                      : isLoanGiven
                      ? 'text-emerald-400'
                      : 'text-amber-400'
                  }`}
                >
                  {isExpense ? '-' : isLoanGiven ? '+ lent $' : '- owes $'}
                  {tx.amount.toFixed(2)}
                </div>
                <span className="text-[9px] text-zinc-500 uppercase">
                  {isExpense ? 'Expense' : isLoanGiven ? 'Loan (You lent)' : 'Loan (You borrowed)'}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Add Transaction Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-sm p-5 rounded-3xl bg-surface border border-white/10 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Wallet className="w-4 h-4 text-primary" />
                  <h3 className="text-sm font-bold text-zinc-100">Add Record</h3>
                </div>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="text-muted hover:text-white text-xs px-2 py-1"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleAddTransaction} className="space-y-3">
                {/* Type Selector */}
                <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-background border border-white/5 text-[10px]">
                  <button
                    type="button"
                    onClick={() => setNewType('expense')}
                    className={`py-1.5 rounded-lg font-medium transition-colors ${
                      newType === 'expense' ? 'bg-zinc-800 text-white font-bold' : 'text-zinc-400'
                    }`}
                  >
                    Expense 💸
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewType('loan_given')}
                    className={`py-1.5 rounded-lg font-medium transition-colors ${
                      newType === 'loan_given' ? 'bg-primary text-[#050506] font-bold' : 'text-zinc-400'
                    }`}
                  >
                    I Lent 🤝
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewType('loan_taken')}
                    className={`py-1.5 rounded-lg font-medium transition-colors ${
                      newType === 'loan_taken' ? 'bg-amber-500 text-black font-bold' : 'text-zinc-400'
                    }`}
                  >
                    I Borrowed 🤲
                  </button>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] text-zinc-400">Description</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dinner with team"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full bg-background border border-white/5 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-primary"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] text-zinc-400">Amount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="0.00"
                    value={newAmount}
                    onChange={(e) => setNewAmount(e.target.value)}
                    className="w-full bg-background border border-white/5 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-primary"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full mt-2 py-3 rounded-xl bg-primary hover:bg-primary-hover text-[#050506] font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Save Record</span>
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
